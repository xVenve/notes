/*
 * Name: PartialExam1_65
 * Description: Solutions to the first partial exam
 * Author: Juan Gomez Romero
 * Version: 1
 * Creation: November 3, 2009
 * Modification: November 3, 2009
 */


public class PartialExam1_65 {

	public static void main(String[] args) {

		/* Question 1 */
		/*int selection = 2;

		String productSelected = "";
		double price;

		switch(selection) {
			case 0:
				productSelected = "Croissant";
				price = 2.50;
				break;
			case 1:
				productSelected = "Expresso";
				price = 1.05;
				break;
			case 2:
				productSelected = "Milk tea";
				price = 1.20;
				break;
			default:
				productSelected = "Unknown";
				price = -1;
		}

		System.out.println("Product: " + productSelected + " (" + price + ")");	*/

		/* Solution:
		 * c
		 * The code is correct. String variables cannot be used as the switch
		 * variable, but in this case, the switch variable is an int. It
		 * is not compulsory to add a break in each case. However, it must
		 * be taken into account that if the break is not included, the
		 * program continues with the next case, even if it is not true,
		 * until the end of the switch or a break are found. Moreover, the
		 * break of the default is superfluous. The + operator for strings
		 * concatenates the operators to create a longer string */



		/* Question 2 */
		/*boolean a = true, b, c = b;		// a
		float d = 3.0F, e = 2.0F, f;		// b
		double g = 3, h = g;				// c
		int i = 1; j = i*2;				// d
		 */

		/* Solution:
		 * a is not correct. c is assigned to b, which has not been initialized. Initialize b
		 * b is correct
		 * c is correct. 3 is an int value which is automatically casted to double
		 * d is not correct. j has no type. int i=1, j=i*2; */




		/* Question 3 */
		/*int x, y;
		double z = 1.0;
		int [] a, b;
		final double w = 2.0;

		x = 5;
		z = x;
		y = z;
		w = z;
		a = new int[10];
		x = a[1];
		y = b[1];*/

		/* Solution:
		 * y = z. Type mismatch: z is double, y is int. Change by: y = (int) z;
		 * w = z. Changing a final variable. Remove final modifier in declaration of w
		 * y = b[1]. b has not been initialized. Initialize b: b = new int[2];
		 */



		/* Question 4 */
		/*char   a = 'c'; int    b = a;
		double a = 500; long   b = a;
		char   a = 'c'; String b = a;
		String a = "A"; String b = a + "B";*/

		/* Solution:
		 * a) is correct. The char is automatically casted to int
		 * b) is not correct. a is a double variable. Casting is required: long b = (long) a;
		 * c) is not correct. A char cannot be directly assigned to a String. Better: String b = "a", or String b = String.toString(a)
		 * d) is correct.
		 */



		/* Question 5 */
		/*int   x = 10, y = 9;
		float r = 15.0F;
		char  c = 'X', d = 'Y';
		String s;
		boolean b;

		if(x <= r) { // 1
			s = "x is less or equal than r. ";
		} else {
			s = "x is greater than r.";
		}

		b = (++y == x);
		if(b) {		// 2
			s += "y is equal to x. ";
			if(c == 'X' && d == 'Y') {		// 3
				s += "c is X, d is Y. ";
			}
		} else {
			s += "y is not equal to x. ";
			if(c != 'X' || d != 'Y') {		// 4
				s += "c is not X, d is not Y. ";
			}
		}

		System.out.println(s);*/

		/* Solution: x is less or equal than r. y is equal to x. c is X, d is Y.
		 * if/else 1 is true; then s is assigned "x is less or equal than r."
		 * y is incremented before the comparison; then, b is true
		 * if/else 2 is true; then s is appended "y is equal to x."
		 * if/else 3 is true; then s is appended "c is X, d is Y."
		 */



		/* Question 6 */
		/*int [] badNumbers = new int[] {4, 8, 15, 16, 23, 42};

		for(int n = 1; n <= 100; n++) {
			boolean isBad = false;

			int i;
			for(i = 0; i < badNumbers.length; i++) {
				if(n == badNumbers[i]) {
					isBad = true;
					break;
				}
			}

			if(isBad) {
				System.out.println("Reached position " + i + ", " + n + " IS a bad number!");
			} else {
				System.out.println("Reached position " + i + ", " + n + " IS NOT a bad number!");
			}
		}	*/

		/* Solution: The program tests for each number n in {1, 2,..., 100} if it is a
		 * 'bad' number. Bad numbers are those in the array badNumbers = {4, 8, 15,
		 * 16, 23, 42}.
		 * If n is not a bad number, the program prints:
		 *   Reached position 6 in array, n is NOT a bad number
		 * If n is a bad number, the program prints:
		 *   Reached position <position in the array of bad numbers>, n IS a bad number
		 *   Example:
		 *   Reached position 4, 23 IS a bad number! */



		/* Problem 1 */
		/*boolean [][] computerLabs;
		computerLabs = new boolean[4][];
		computerLabs[0] = new boolean[25];
		computerLabs[1] = new boolean[30];
		computerLabs[2] = new boolean[35];
		computerLabs[3] = new boolean[50];

		computerLabs[1][0]  = true;
		computerLabs[1][29] = true;*/



		/* Problem 2 */
		/* double x = 1, y = 2, z = -1;
		double f;

		// Beginning of your solution
		if(z > 0) {
			if(x > y)
				f = x;
			else
				f = y;
		} else {
			if (z == 0)
				f = 0;
			else
				if(x < y)
					f = x;
				else
					f = y;
		}

		// Alternative
		if(z > 0)
			f = x > y? x:y;
		else if (z == 0)
			f = 0;
		else
			f = x < y? x:y;

		//End of your solution
		System.out.println(f);*/


		/* Problem 3 */
		/* char [][] Q = new char[][] {
				{'1', 'X', 'X', '2', '2', 'X'},
				{'1', '2', '2', '1', '1', 'X'},
				{'2', 'X', 'X', 'X', '1', '2'},
				{'1', 'X', '2', '1', 'X', '1'}
		};


		// Beginning of your solution
		int ones = 0, draws = 0, twos = 0;

		for(int i=0; i<Q.length; i++)
			for(int j=0; j<Q[i].length; j++)
				switch(Q[i][j]) {
					case '1': ones++;
							  break;
					case '2': twos++;
							  break;
					case 'X': draws++;
					          break;
					default:  System.out.println("Unrecognized character");
				}
		// End of your solution

		System.out.println("Number of '1': " + ones);
		System.out.println("Number of 'X': " + draws);
		System.out.println("Number of '2': " + twos);*/
	}

}
