/*
 * Name: PartialExam1_89
 * Description: Solutions to the first partial exam
 * Author: Juan Gomez Romero
 * Version: 1
 * Creation: November 3, 2009
 * Modification: November 3, 2009
 */

public class PartialExam1_89 {

	public static void main(String[] args) {

		/* Question 1 */
		/*char c = 'B';

		switch(c) {
			case 'A':
				System.out.println("A was selected");
				break;
			case 'B':
				System.out.println("B was selected");
			case 'C':
				System.out.println("C was selected");
				break;
			default:
				System.out.println("Selection other than A, B, or C");
		}*/

		/* Solution:
		 * d
		 * The code is correct. int variables can be used in switch, and it
		 * is not compulsory to add a break in each case. However, it must
		 * be taken into account that if the break is not included, the
		 * program continues with the next case, even if it is not true,
		 * until the end of the switch or a break are found */


		/* Question 2 */
		/* float a = 3.0, b = 2.0F, c;
		char d = 'aa', e = 'bb', f = 'cc';
		int  g = 1, double h = 5.1;
		int i; int j; */

		/* Solution:
		 * a is not correct. 3.0 is a double and cannot be assigned to a float. Type 3.0F
		 * b is not correct. 'aa' is not a valid character. 'aa'-->'a' or d must be a String. Analogously for e and f
		 * c is not correct. Multiple declarations are not allowed in this format. int g = 1; double h = 5.1
		 * d is correct. */


		/* Question 3 */
		/*int [] a, b;
		int [] c, d;
		int e;
		final double x = 1.0;
		float y;

		a = new int[5];
		b = new int[5];
		a[0] = b[0];
		a[1] = b[1] + e;
		y = x;
		y = (double) (x + 1);		*/

		/* Solution:
		 * a[1] = b[1] + e is not correct; e has not been initialized. Add e = 0;
		 * y = x; type mismatch: x is a double. Change by y = (float) x;
		 * y = (double) (x + 1); y is a float and the casting is to double. Change by y = (float) (x+1) */



		/* Question 4 */
		/*double a = 500; float  b = a;
		boolean a = 1; boolean b = a;
		long   a = 4, b = a + 1;
		String a = "1" + "2";*/

		/* Solution:
		 * a is not correct. Type mismatch. Casting required: float b = (float) a;
		 * b is not correct. Type mismatch. Integer values cannot be assigned to  booleans. Change 1 by true.
		 * c is correct.
		 * d is correct. The + operator concatenates strings */



		/* Question 5 */
/*		int   x = 10, y = 9;
		float r = 15.0F;
		char  c = 'X', d = 'Y';
		String s;
		boolean b;

		if(x <= r) { // 1
			s = "x is less or equal than r. ";
		} else {
			s = "x is greater than r.";
		}

		b = (y++ == x);
		if(b) {		// 2
			s += "y is equal to x. ";
			if(c == 'X' && d == 'Y') {		// 3
				s += "c is X, d is Y. ";
			}
		} else {
			s += "y is not equal to x. ";
			if(c != 'X' || d != 'Y') {		// 4
				s += "c is not X, d is not Y. ";
			}
		}

		System.out.println(s);*/

		/* Solution: x is less or equal than r. y is not equal to x.
		 * Condition of if/else 1 is true, then s = "x is less or equal than r".
		 * The increment of y is performed after the comparison. Then, b is false.
		 * Condition of if/else 2 is false, then "y is not equal to x" is added to s.
		 * Condition of if/else 4 is false, then nothing happens
		 */

		/* Question 6 */
/*		int [] badNumbers = new int[] {4, 8, 15, 16, 23, 42};

		for(int n = 1; n <= 100; n++) {

		  int i = 0;
		  boolean isBad = false;

		  while(i < badNumbers.length && !isBad) {
		    if(n == badNumbers[i]) {
		      isBad = true;
		    }
		    i++;
		  }

		  if(isBad) {
		    System.out.println("After " + i + " tests, " + n + " IS a bad number!");
		  } else {
		    System.out.println("After " + i + " tests, " + n + " IS NOT a bad number!");
		  }
		}*/

		/* Solution: The program tests for each number n in {1, 2,..., 100} if it is a
		 * 'bad' number. Bad numbers are those in the array badNumbers = {4, 8, 15,
		 * 16, 23, 42}.
		 * If n is not a bad number, the program prints:
		 *   After 6 tests, n IS NOT a bad number
		 * If n is a bad number, the program prints:
		 *   After <position in the array of bad numbers>, n IS a bad number
		 *   Example:
		 *   After 5 tests, 23 IS a bad number! */



		/* Problem 1 */
		/*String [][] train;
		train = new String[5][];
		train[0] = new String[20];
		train[1] = new String[20];
		train[2] = new String[35];
		train[3] = new String[35];
		train[4] = new String[35];

		train[4][0]  = "John Doe";
		train[4][34] = "Betty Boop";*/




		/* Problem 2 */
		/*double x = 1, y = 2, z = -1;
		double f;

		// Beginning of your solution
		double pre_result;

		if(z > 0) {
			pre_result = x + y;
			if(pre_result > 0)
				f = pre_result;
			else
				f = -pre_result;
		} else {
			if(z == 0)
				f = 0;
			else {
				pre_result = x - y;
				if(pre_result > 0)
					f = pre_result;
				else
					f = -pre_result;
			}
		}

		// Alternative
		if(z > 0)
			f = (x+y>0)? (x+y) : -(x+y);
		else if (z == 0)
			f = 0;
		else
			f = (x-y>0)? (x-y) : -(x-y);

		// End of your solution
		System.out.println(f);*/




		/* Problem 3 */
		/*int [] A = new int [] {4, 3, 6, 7, 4, 5, 2, 8, 9, 1};
		int maxOfA;

		// Beginning of your solution
		maxOfA = Integer.MIN_VALUE;     // Alternatively, assuming that A[j] > 0 for all j, maxOfA = 0;
		if(A.length > 0) {
			maxOfA = A[0];

			for(int i=1; i < A.length; i++) {
				if(A[i] > maxOfA)
					maxOfA = A[i];
			}
		}
		// End of your solution
		System.out.println("Maximum value of A is " + maxOfA);*/



	}

}
